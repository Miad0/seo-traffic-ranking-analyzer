# SEO Traffic & Ranking Analyzer

A small Python data analysis project that analyzes SEO performance data and produces practical insights you can discuss in interviews.

## Why this project works for a resume

This project shows that you can:
- clean real-world marketing data with Python
- calculate business-relevant SEO metrics
- find optimization opportunities from data
- create charts and summary outputs
- structure a project professionally for GitHub

## Project idea

The script analyzes search performance data similar to a Google Search Console export. It identifies:
- top-performing pages
- keyword opportunities ranking in positions 8 to 15
- pages with high impressions but weak CTR
- possible keyword cannibalization
- daily traffic trends

## Folder structure

```bash
seo_traffic_ranking_analyzer/
├── app.py
├── main.py
├── README.md
├── requirements.txt
├── data/
│   └── seo_sample_data.csv
├── output/
└── src/
    ├── analysis.py
    ├── cleaning.py
    └── visualization.py
```

## How to run

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Run the analysis script

```bash
python main.py
```

This creates CSV reports and chart images in the `output/` folder.

### 3. Run the dashboard

```bash
streamlit run app.py
```

## Example outputs

- `top_pages.csv`
- `keyword_opportunities.csv`
- `low_ctr_pages.csv`
- `cannibalization_report.csv`
- `daily_performance.csv`
- `daily_clicks.png`
- `ctr_vs_position.png`
- `top_pages_clicks.png`
- `summary.txt`

## Suggested interview explanation

> I built a Python-based SEO analytics project that takes search performance data, cleans it with pandas, analyzes ranking and CTR patterns, identifies pages and queries with optimization potential, and outputs both charts and summary reports. I also added a Streamlit dashboard so the insights can be explored interactively.

## Good GitHub improvements

You can improve this later by adding:
- Google Search Console API integration
- keyword clustering with NLP
- anomaly detection for traffic drops
- automated PDF report generation
- unit tests

## Dataset note

The included CSV is synthetic sample data generated for portfolio practice.
